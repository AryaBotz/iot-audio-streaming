# IoT Audio Streaming (ZIP VERSION)

This is a packaged version of ESP32 + Node.js backend for WebSocket audio streaming.
