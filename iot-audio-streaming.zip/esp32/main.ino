#include <WiFi.h>
#include <WebSocketsClient.h>
#include "BluetoothA2DPSink.h"
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

// ============= CONFIG =============
const char* SSID = "YOUR_SSID";
const char* PASSWORD = "YOUR_PASSWORD";
const char* WS_HOST = "your-backend-url.up.railway.app";
const uint16_t WS_PORT = 443;
const char* WS_PATH = "/ws/audio";

// (truncated for zip simplicity in this demo context)
