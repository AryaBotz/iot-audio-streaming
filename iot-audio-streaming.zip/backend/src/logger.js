const logLevel = process.env.LOG_LEVEL || 'info';
const levels = { debug:0, info:1, warn:2, error:3 };
const currentLevel = levels[logLevel] || 1;

function shouldLog(level){ return levels[level] >= currentLevel; }

function t(){ return new Date().toISOString(); }

module.exports = {
 info:(m)=>shouldLog('info')&&console.log(`[${t()}] INFO: ${m}`),
 warn:(m)=>shouldLog('warn')&&console.warn(`[${t()}] WARN: ${m}`),
 error:(m)=>shouldLog('error')&&console.error(`[${t()}] ERROR: ${m}`)
};