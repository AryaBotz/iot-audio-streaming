const fs = require('fs');
module.exports = { transcribe: async()=>"(mock)" };