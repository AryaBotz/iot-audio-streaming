module.exports = {
 createClient:()=>({}),
 handleAudioChunk:async()=>{},
 cleanupClient:()=>{},
 getClientCount:()=>0
};